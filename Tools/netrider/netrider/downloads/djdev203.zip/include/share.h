/* Copyright (C) 1995 DJ Delorie, see COPYING.DJ for details */
/* DO NOT USE THIS IN NEW CODE.  It is here only
   to allow old code to compile. */

#include <fcntl.h>
